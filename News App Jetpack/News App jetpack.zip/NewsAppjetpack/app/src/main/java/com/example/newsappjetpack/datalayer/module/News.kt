package com.example.newsappjetpack.datalayer.module

data class News(
    val category: String,
    val `data`: List<Data>,
    var success: Boolean
)