package com.example.cartonboxmeasurementapp.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.newsappjetpack.datalayer.NewsData
import kotlinx.coroutines.flow.Flow

@Dao
interface NewsDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(news: NewsData)

    @Delete
    suspend fun delete(news: NewsData)

    @Query("Select * from newsdata where newsId=:id")
    suspend fun getReportById(id: Int): NewsData?

    @Query("select * from newsdata")
    fun getReports(): Flow<List<NewsData>>

    @Query("delete from newsdata")
    fun deleteall()
}