package com.example.newsappjetpack.ui.screen

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.compose.runtime.collectAsState
import androidx.annotation.RequiresExtension
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.outlined.CodeOff
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.Newspaper
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.net.ConnectivityManagerCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.example.newsappjetpack.datalayer.NewsData
import com.example.newsappjetpack.datalayer.module.TabItem
import com.example.newsappjetpack.util.ConnectionState
import com.example.newsappjetpack.util.FeedViewModel
import com.example.newsappjetpack.util.NetworkState
import com.example.newsappjetpack.util.Route
import com.example.newsappjetpack.viewmodel.Theme

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import kotlin.time.Duration.Companion.seconds

@RequiresApi(Build.VERSION_CODES.O)
@RequiresExtension(extension = Build.VERSION_CODES.S, version = 7)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(
    ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class,
    ExperimentalCoroutinesApi::class
)
@Composable
fun NewsScreen(
    navigate: NavHostController,
    viewModel: FeedViewModel = hiltViewModel()
) {
    val category = viewModel.category
    val listState = rememberLazyListState()
    val dbNews by viewModel.dbNews.collectAsState(initial = emptyList())
//    var internet by remember {
//        mutableStateOf(false)
//    }
//    internet=viewModel.isInternetAvailable(LocalContext.current)
    val networkConnectivity by connectivityState()
    val tabItem = listOf(
        TabItem(
            title = "News",
            unSelectedIcon = Icons.Outlined.Newspaper,
            selectedItem = Icons.Filled.Newspaper
        ),
        TabItem(
            title = "Weather",
            unSelectedIcon = Icons.Outlined.WbSunny,
            selectedItem = Icons.Filled.WbSunny
        )

    )
    var selectedTabIndex by remember {
        mutableStateOf(0)
    }
    val pageState = rememberPagerState {
        tabItem.size
    }
    LaunchedEffect(selectedTabIndex) {
        pageState.animateScrollToPage(selectedTabIndex)
    }
    LaunchedEffect(pageState.currentPage) {
        selectedTabIndex=pageState.currentPage
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Home",
                        fontSize = MaterialTheme.typography.titleLarge.fontSize
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                ),
                actions = {
                    IconButton(onClick = {
                        navigate.navigate(Route.OFFLINE_NEWS)
                    }) {
                        Icon(
                            imageVector = Icons.Outlined.CodeOff,
                            contentDescription = "Offline",
                        )

                    }
                    IconButton(onClick = {
                        Theme.darktheme.value = !Theme.darktheme.value
                        viewModel.darkModeClicked = !viewModel.darkModeClicked
                    }) {
                        if (viewModel.darkModeClicked) {
                            Icon(
                                imageVector = Icons.Outlined.LightMode,
                                contentDescription = "Mode",
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Outlined.DarkMode,
                                contentDescription = "Delete All",
                            )
                        }

                    }
                },
            )
        }, floatingActionButton = {
            FloatingActionButton(onClick = {
                navigate.navigate(Route.ADD_NEWS)
            }) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add"
                )
            }
        }
    ) { innerPadding ->
        if (networkConnectivity == ConnectionState.Unavailable) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(

                    text = "Oops look like no internet connection",
                    fontSize = MaterialTheme.typography.titleLarge.fontSize,
                    fontWeight = MaterialTheme.typography.titleLarge.fontWeight
                )
                Spacer(modifier = Modifier.height(5.dp))
                Icon(
                    imageVector = Icons.Default.CloudOff,
                    tint = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .size(200.dp),
                    contentDescription = null,

                    )
                Spacer(modifier = Modifier.height(5.dp))
                Button(
                    onClick = { navigate.navigate(Route.OFFLINE_NEWS) },
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) {
                    Text(text = "Offline News")
                }
            }

        } else {
            Column(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize()
                    .padding(horizontal = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                TabRow(selectedTabIndex = selectedTabIndex) {
                    tabItem.forEachIndexed { index, item ->
                        Tab(
                            selected = index == selectedTabIndex,
                            onClick = { selectedTabIndex = index },
                            icon = {
                                Icon(
                                    imageVector = if (index == selectedTabIndex) {
                                        item.selectedItem
                                    } else {
                                        item.unSelectedIcon
                                    },
                                    contentDescription = item.title
                                )
                            })
                    }


                }
                HorizontalPager(state = pageState, modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)) { index->
                    if(index==0){
                       NewsFeedScreen(category,navigate,viewModel,dbNews,listState)
                    }else{
                        WeatherScreen()
                    }

                }

            }
        }
    }
}

@RequiresExtension(extension = Build.VERSION_CODES.S, version = 7)
@Composable
fun NewsFeedScreen(
    category: List<String>,
    navigate: NavHostController,
    viewModel: FeedViewModel,
    dbNews: List<NewsData>,
    listState: LazyListState,
) {
    Column {
        LazyRow(
            modifier = Modifier.padding(5.dp),
            state = listState
        ) {
            items(category) { category ->
                CategoryItem(category = category, viewModel)
            }
        }
        Feed(viewModel = viewModel, navigate, dbNews)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@RequiresExtension(extension = Build.VERSION_CODES.S, version = 7)
@Composable
fun Feed(viewModel: FeedViewModel, navigate: NavHostController, dbNews: List<NewsData>) {
    val combinedNews = remember { mutableStateListOf<NewsData>() }
    LaunchedEffect(dbNews) {
        combinedNews.clear()
        combinedNews.addAll(dbNews)
    }
    when (viewModel.uiState) {
        is FeedViewModel.UiState.Loading -> {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                CircularProgressIndicator(
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        is FeedViewModel.UiState.Success -> {
            LazyColumn {
                // Display items
                items(items = combinedNews,
                    key = { it.newsId }) { news ->
                    if (news.id.indexOf("New") != -1) {
                        SwipeTODismissItem(
                            item = news,
                            onRemove = {
                                viewModel.delete(news)
                                combinedNews.remove(news)
                                Log.d("recompose", news.toString() + " " + combinedNews.size)
                            },
                            modifier = Modifier.animateItemPlacement(tween(200)),

                            navigate = navigate, viewModel
                        )
                    }
                }
                viewModel.news.value?.let {
                    items(it.data) { news ->
                        NewsCard(data = news, navigate = navigate)
                    }
                }

            }
        }

        else -> {}
    }
}

@RequiresExtension(extension = Build.VERSION_CODES.S, version = 7)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SwipeTODismissItem(
    item: NewsData,
    onRemove: () -> Unit,
    modifier: Modifier,
    navigate: NavHostController,
    viewModel: FeedViewModel
) {
    val coroutineScope = rememberCoroutineScope()
    val swipeToDismissBoxState = rememberSwipeToDismissBoxState(
        confirmValueChange = { state ->
            if (state == SwipeToDismissBoxValue.EndToStart) {
                coroutineScope.launch {
                    delay(1.seconds)
                    onRemove()
                }
                true
            } else {
                false
            }
        }
    )
    SwipeToDismissBox(
        state = swipeToDismissBoxState,
        backgroundContent = {
            val backgroundColor by animateColorAsState(
                targetValue =
                when (swipeToDismissBoxState.currentValue) {
                    SwipeToDismissBoxValue.StartToEnd -> Color.Green
                    SwipeToDismissBoxValue.EndToStart -> Color.Red
                    SwipeToDismissBoxValue.Settled -> MaterialTheme.colorScheme.surface
                }
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(backgroundColor)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete, contentDescription = "delete",
                    tint = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        },
        modifier = Modifier
    ) {

        NewsCardData(item, navigate = navigate, viewModel)
    }
}

@ExperimentalCoroutinesApi
@Composable
fun connectivityState(): State<ConnectionState> {
    val context = LocalContext.current
    return produceState<ConnectionState>(initialValue = ConnectionState.Unavailable) {
        context.observeConnectivityAsFlow().collect { value = it }
    }
}

@Suppress("DEPRECATION")
private val ConnectivityManager.activeNetworkState: NetworkState
    @SuppressLint("MissingPermission")
    get() {
        // Use getActiveNetworkInfo() instead of getNetworkInfo(network) because it can detect VPNs.
        val info = activeNetworkInfo
        val isConnected = info != null && info.isConnected
        val isValidated = isActiveNetworkValidated
        val isMetered = ConnectivityManagerCompat.isActiveNetworkMetered(this)
        val isNotRoaming = info != null && !info.isRoaming
        return NetworkState(isConnected, isValidated, isMetered, isNotRoaming)
    }


private val ConnectivityManager.isActiveNetworkValidated: Boolean
    @SuppressLint("RestrictedApi", "MissingPermission")
    get() =
        if (Build.VERSION.SDK_INT < 23) {
            false // NET_CAPABILITY_VALIDATED not available until API 23. Used on API 26+.
        } else
            try {
                val network = activeNetwork
                val capabilities = getNetworkCapabilities(network)
                (capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) ?: false
            } catch (exception: SecurityException) {

                false
            }

/** Network Utility to observe Internet connectivity status */
@SuppressLint("MissingPermission")
@ExperimentalCoroutinesApi
private fun Context.observeConnectivityAsFlow() =
    callbackFlow {
        val connectivityManager =
            getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        fun sendConnectionState() =
            with(connectivityManager.activeNetworkState) {
                if (Build.VERSION.SDK_INT < 23) {
                    if (isConnected) {
                        trySend(ConnectionState.Available)
                    } else {
                        trySend(ConnectionState.Unavailable)
                    }
                } else {
                    if (isConnected && isValidated) {
                        trySend(ConnectionState.Available)
                    } else {
                        trySend(ConnectionState.Unavailable)
                    }
                }
            }

        val networkRequest =
            NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
                .build()

        val networkCallback =
            object : ConnectivityManager.NetworkCallback() {
                // satisfies network capability and transport requirements requested in networkRequest
                override fun onCapabilitiesChanged(
                    network: Network,
                    networkCapabilities: NetworkCapabilities
                ) {
                    sendConnectionState()
                }

                override fun onLost(network: Network) {
                    sendConnectionState()
                }
            }

        connectivityManager.registerNetworkCallback(networkRequest, networkCallback)

        awaitClose {
            connectivityManager.unregisterNetworkCallback(networkCallback)
        }
    }
        .distinctUntilChanged()
        .flowOn(Dispatchers.IO)