package com.example.newsappjetpack.repository

import android.os.Build
import androidx.annotation.RequiresApi
import com.example.cartonboxmeasurementapp.data.NewsDao
import com.example.newsappjetpack.api.WeatherApi
import com.example.newsappjetpack.api.mappers.toWeatherInfo
import com.example.newsappjetpack.api.weatherApi
import com.example.newsappjetpack.datalayer.NewsData
import com.example.newsappjetpack.util.Resource
import com.example.newsappjetpack.weather.WeatherInfo
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class NewsRepositoryImpl ( private val dao: NewsDao): NewsRepository {

    override suspend fun insert(news: NewsData) {
       dao.insert(news)
    }

    override suspend fun delete(news: NewsData) {
      dao.delete(news)
    }

    override suspend fun getNewsById(id: Int): NewsData? {
        return dao.getReportById(id)
    }

    override fun getNews(): Flow<List<NewsData>> {
        return dao.getReports()
    }

    override suspend fun deleteAllNews() {
        return dao.deleteall()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override suspend fun getWeatherData(lat: Double, long: Double): Resource<WeatherInfo> {
        return try {
            Resource.Success(
                data = weatherApi.getWeatherData(
                    lat = lat,
                    long = long
                ).toWeatherInfo()
            )
        } catch(e: Exception) {
            e.printStackTrace()
            Resource.Error(e.message ?: "An unknown error occurred.")
        }
    }

}