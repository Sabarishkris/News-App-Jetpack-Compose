package com.example.newsappjetpack.ui.screen

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.provider.MediaStore.Images.Media.getBitmap
import android.util.Log
import androidx.annotation.RequiresExtension
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.net.toUri
import androidx.navigation.NavHostController
import coil.compose.rememberAsyncImagePainter
import com.example.newsappjetpack.datalayer.NewsData
import com.example.newsappjetpack.datalayer.module.Data

import com.example.newsappjetpack.util.FeedViewModel
import com.example.newsappjetpack.util.Route
import com.example.newsappjetpack.viewmodel.WeatherViewModel
import kotlinx.coroutines.launch
import java.util.Locale

@RequiresExtension(extension = Build.VERSION_CODES.S, version = 7)
@Composable
fun CategoryItem(category: String, viewModel: FeedViewModel) {
    val isSelected = viewModel.categoryPosition.value == category

    Card(
        onClick = {
            viewModel.categoryPosition.value = category
            viewModel.fetchNews()
        },
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected)
                MaterialTheme.colorScheme.primary
            else
                MaterialTheme.colorScheme.surface
        ),
        modifier = Modifier.padding(end = 3.dp)
    ) {
        Text(
            text = category.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() },
            fontSize = MaterialTheme.typography.titleMedium.fontSize,
            fontWeight = MaterialTheme.typography.bodyLarge.fontWeight,
            modifier = Modifier.padding(5.dp),
            color = if (isSelected)
                MaterialTheme.colorScheme.surface
            else
                MaterialTheme.colorScheme.onSurface
        )
    }
}


@SuppressLint("CoroutineCreationDuringComposition")
@RequiresExtension(extension = Build.VERSION_CODES.S, version = 7)
@Composable
fun NewsCardData(newsdata: NewsData, navigate: NavHostController, viewModel: FeedViewModel) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(220.dp)
            .padding(5.dp)
    ) {
        Card(
            onClick = {
                navigate.currentBackStackEntry?.savedStateHandle?.set(
                    key = "data",
                    value = newsdata
                )
                navigate.navigate(Route.NEWS_VIEW)
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(15.dp),

            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        ) {
            Box(modifier = Modifier.height(220.dp))
            {

                    Image(
                         painter =  rememberAsyncImagePainter(newsdata.imageUrl),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                    )

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color.Black
                                ), startY = 200f
                            )
                        )
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(5.dp),
                    contentAlignment = Alignment.BottomStart
                ) {
                    Text(
                        text = newsdata.title,
                        fontSize = MaterialTheme.typography.titleSmall.fontSize,
                        fontWeight = MaterialTheme.typography.titleMedium.fontWeight,
                        modifier = Modifier.padding(bottom = 12.dp),
                        textAlign = TextAlign.Center,
                        color = Color.White
                    )
                }
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.BottomEnd
                ) {
                    Text(
                        text = newsdata.date,
                        color = Color.White,
                        fontSize = MaterialTheme.typography.labelSmall.fontSize,
                        fontWeight = MaterialTheme.typography.labelSmall.fontWeight,
                        modifier = Modifier.padding(end = 5.dp)
                    )

                }
            }
        }
    }
}

@RequiresExtension(extension = Build.VERSION_CODES.S, version = 7)
@Composable
fun NewsCard(data: Data, navigate: NavHostController) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(220.dp)
            .padding(5.dp)
    ) {
        Card(
            onClick = {
                navigate.currentBackStackEntry?.savedStateHandle?.set(
                    key = "data",
                    value = data
                )
                navigate.navigate(Route.NEWS_VIEW)
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(15.dp),

            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        ) {
            Box(modifier = Modifier.height(220.dp))
            {
//                val image=data.imageUrl as Bitmap
                Image(
                    painter = rememberAsyncImagePainter(data.imageUrl),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color.Black
                                ), startY = 200f
                            )
                        )
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(5.dp),
                    contentAlignment = Alignment.BottomStart
                ) {
                    Text(
                        text = data.title,
                        fontSize = MaterialTheme.typography.titleSmall.fontSize,
                        fontWeight = MaterialTheme.typography.titleMedium.fontWeight,
                        modifier = Modifier.padding(bottom = 12.dp),
                        textAlign = TextAlign.Center,
                        color = Color.White
                    )
                }
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.BottomEnd
                ) {
                    Text(
                        text = data.date,
                        color = Color.White,
                        fontSize = MaterialTheme.typography.labelSmall.fontSize,
                        fontWeight = MaterialTheme.typography.labelSmall.fontWeight,
                        modifier = Modifier.padding(end = 5.dp)
                    )

                }
            }
        }
    }
}
