package com.example.newsappjetpack.viewmodel

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel

sealed class Theme{
    companion object{
        var darktheme= mutableStateOf(false)
    }
    sealed class UiState {
        object Success : UiState()
        object Error : UiState()
        object Loading : UiState()
    }
}