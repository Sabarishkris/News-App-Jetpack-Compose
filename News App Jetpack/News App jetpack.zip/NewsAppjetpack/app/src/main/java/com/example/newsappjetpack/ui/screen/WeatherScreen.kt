package com.example.newsappjetpack.ui.screen

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.newsappjetpack.viewmodel.WeatherViewModel
import com.plcoding.weatherapp.presentation.WeatherForecast

@RequiresApi(Build.VERSION_CODES.O)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeatherScreen(viewModel: WeatherViewModel= hiltViewModel()) {
    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        viewModel.loadWeatherInfo()
        val context= LocalContext.current
        viewModel.cityName(context,9.8839782,78.12056)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.primary)

        ) {
            WeatherCard(
                state = viewModel.state,
                backgroundColor = MaterialTheme.colorScheme.secondary,
                city=viewModel.city
            )
            Spacer(modifier = Modifier.height(16.dp))
            WeatherForecast(state = viewModel.state)
        }
        if(viewModel.state.isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.align(Alignment.Center)
            )
        }
        viewModel.state.error?.let { error ->
            Text(
                text = error,
                color = Color.Red,
                textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.Center)
            )
        }
    }
}


//@Composable
//fun CircularProgressBar() {
//    Box(contentAlignment = Alignment.Center) {
//        CircularProgressIndicator(
//            modifier = Modifier
//                .size(70.dp)
//                .padding(16.dp)
//                .wrapContentSize(Alignment.Center)
//        )
//    }
//}