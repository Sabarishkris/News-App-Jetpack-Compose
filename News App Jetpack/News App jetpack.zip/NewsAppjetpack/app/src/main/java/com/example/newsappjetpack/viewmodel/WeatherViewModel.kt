package com.example.newsappjetpack.viewmodel

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.util.Log
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
//import com.example.newsappjetpack.location.LocationTracker
import com.example.newsappjetpack.repository.NewsRepository
import com.example.newsappjetpack.util.Resource
import com.example.newsappjetpack.util.WeatherState
import com.google.android.gms.location.FusedLocationProviderClient

import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import javax.inject.Inject
import kotlin.coroutines.resume

@HiltViewModel
class WeatherViewModel @Inject constructor(
    private val repository: NewsRepository,
    private val locationClient: FusedLocationProviderClient,
    private val application: Application
) : ViewModel() {


//    private lateinit var permissionLauncher: ActivityResultLauncher<Array<String>>

    var state by mutableStateOf(WeatherState())
        private set
    var city by mutableStateOf("")
    fun cityName(context: Context, myLat: Double, myLong: Double) {
        val geocoder = Geocoder(context, Locale.getDefault())
        val addresses: MutableList<Address>? = geocoder.getFromLocation(myLat, myLong, 1)

        if (!addresses.isNullOrEmpty()) {
            val address: Address = addresses[0]
            val cityName: String? = address.getAddressLine(0)
//            val stateName: String? = address.getAddressLine(1)
//            val countryName: String? = address.getAddressLine(2)

            if (cityName != null) {
                var str=cityName.split(",")
                city=str.get(str.size-3)
                Log.d("cityname", city)
            }
        }
    }

    fun loadWeatherInfo() {
        viewModelScope.launch {
//            state = state.copy(
//                isLoading = true,
//                error = null
//            )
            getCurrentLocation()?.let { location ->
                Log.d("location", "${location.latitude} ${location.longitude}")
//                when (
                val result = repository.getWeatherData(location.latitude, location.longitude)
//                ) {
//                    is Resource.Success -> {

                state = state.copy(
                    weatherInfo = result.data,
                    isLoading = false,
                    error = null
                )
            }

//                    is Resource.Error -> {
//                        state = state.copy(
//                            weatherInfo = null,
//                            isLoading = false,
//                            error = result.message
//                        )
//                    }
//                }
//            } ?: kotlin.run {
//                state = state.copy(
//                    isLoading = false,
//                    error = "Couldn't retrieve location. Make sure to grant permission and enable GPS."
//                )

        }
    }

    suspend fun getCurrentLocation(): Location? {
        val hasAccessFineLocationPermission = ContextCompat.checkSelfPermission(
            application,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val hasAccessCoarseLocationPermission = ContextCompat.checkSelfPermission(
            application,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val locationManager =
            application.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val isGpsEnabled =
            locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) ||
                    locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
        if (!hasAccessCoarseLocationPermission || !hasAccessFineLocationPermission || !isGpsEnabled) {
            return null
        }

        return suspendCancellableCoroutine { cont ->
            locationClient.lastLocation.apply {
                if (isComplete) {
                    if (isSuccessful) {
                        cont.resume(result)
                    } else {
                        cont.resume(null)
                    }
                    return@suspendCancellableCoroutine
                }
                addOnSuccessListener {
                    cont.resume(it)
                }
                addOnFailureListener {
                    cont.resume(null)
                }
                addOnCanceledListener {
                    cont.cancel()
                }
            }
        }
    }
}