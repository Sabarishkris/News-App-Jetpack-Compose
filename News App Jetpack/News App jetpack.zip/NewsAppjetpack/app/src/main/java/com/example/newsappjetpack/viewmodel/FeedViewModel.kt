package com.example.newsappjetpack.util

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.http.HttpException
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresExtension
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Search
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.core.graphics.drawable.toBitmap
import androidx.core.net.ConnectivityManagerCompat
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.ImageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.example.newsappjetpack.datalayer.NewsData
import com.example.newsappjetpack.datalayer.module.Data
import com.example.newsappjetpack.datalayer.module.News
import com.example.newsappjetpack.repository.NewsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.count
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import javax.inject.Inject

@RequiresExtension(extension = Build.VERSION_CODES.S, version = 7)
@HiltViewModel
class FeedViewModel @Inject constructor(var repository: NewsRepository) : ViewModel() {
    sealed class UiState {
        object Success : UiState()
        object Error : UiState()
        object Loading : UiState()
    }

    var internet by mutableStateOf(true)
    private val _isSwipe= MutableStateFlow(false)
    val isSwipe=_isSwipe.asStateFlow()
    fun swipe(){
        viewModelScope.launch {
            _isSwipe.value = true
//            delay(500L)
            fetchNews()
            _isSwipe.value=false
        }
    }
    var darkModeClicked by mutableStateOf(false)
    var uiState: UiState by mutableStateOf(UiState.Loading)
        private set

    private val _news = MutableLiveData<News>()
    val news: LiveData<News> get() = _news

//
//    private val _uiEvents = Channel<UiEvents>()
//    val uiEvents = _uiEvents.receiveAsFlow()

    var dbNews=repository.getNews()

    var category: List<String> = listOf(
        "national",
        "business",
        "sports",
        "world",
        "politics",
        "technology",
        "startup",
        "entertainment",
        "miscellaneous",
        "hatke",
        "science",
        "automobile"
    )


    val categoryPosition = mutableStateOf(category[0])
//val networkCallback=NetworkCallback()
    init {
        fetchNews()
        dbNews = repository.getNews()
        Log.d("dbnews",dbNews.toString())
    }


    fun fetchNews() {
        viewModelScope.launch {
            uiState = UiState.Loading
            try {
                val response = withContext(Dispatchers.Main) {
                    repository.getTopHeadlines(categoryPosition.value)
                }
                if (response.isSuccessful) {
                    withContext(Dispatchers.Main) {
                        _news.value = response.body()
                        uiState = UiState.Success
                        Log.d("ViewModel", "Success")
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        uiState = UiState.Error
                        Log.e("ViewModel", "Error: ${response.message()}")
                    }
                }
            } catch (e: IOException) {
                withContext(Dispatchers.Main) {
                    _news.value?.success=false
                    uiState = UiState.Error
                    Log.e("ViewModel", "Network error", e)
                }
            } catch (e: HttpException) {
                withContext(Dispatchers.Main) {
                    uiState = UiState.Error
                    Log.e("ViewModel", "HTTP error", e)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    uiState = UiState.Error
                    Log.e("ViewModel", "Unexpected error", e)
                }
            }
        }
    }


    fun delete(news: NewsData) {
        viewModelScope.launch {
            repository.delete(news)
        }
    }

//    fun fetchNewsDb() {
//        viewModelScope.launch {
//            uiState = UiState.Loading
//            // Collect the flow and filter the results
//            dbNews?.collect { newsList ->
//                val filteredNews = newsList.filter { news ->
//                    Log.d("Db", news.toString())
//                    news.id.contains("New", ignoreCase = true)
//                }
//                _dbNews.value = filteredNews
//            }
//
//            uiState = UiState.Success
//            Log.d("ViewModel", "Success")
//        }
//    }

//    suspend fun stringToBitmap(filePath: String): Bitmap? {
//        return BitmapFactory.decodeFile(filePath)
//    }
//    suspend fun stringToBitmap(url: String): Bitmap? {
//        return withContext(Dispatchers.IO) {
//            try {
//                val client = OkHttpClient()
//                val request = Request.Builder().url(url).build()
//                client.newCall(request).execute().use { response ->
//                    val inputStream = response.body?.byteStream()
//                    BitmapFactory.decodeStream(inputStream)
//                }
//            } catch (e: Exception) {
//                e.printStackTrace()
//                null
//            }
//        }
//    }
//     suspend fun getBitmap(context: Context, url: String): Bitmap? {
//        val imageLoader = ImageLoader(context)
//        val request = ImageRequest.Builder(context)
//            .data(url)
//            .build()
//
//        val result = imageLoader.execute(request)
//        return (result as? SuccessResult)?.drawable?.toBitmap()
//    }

//    fun isInternetAvailable(context: Context): Boolean {
//        var result = false
//        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//            val networkCapabilities = connectivityManager.activeNetwork ?: return false
//            val actNw = connectivityManager.getNetworkCapabilities(networkCapabilities) ?: return false
//            result = when {
//                actNw.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
//                actNw.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
//                actNw.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> true
//                else -> false
//            }
//        } else {
//            connectivityManager.run {
//                connectivityManager.activeNetworkInfo?.run {
//                    result = when (type) {
//                        ConnectivityManager.TYPE_WIFI -> true
//                        ConnectivityManager.TYPE_MOBILE -> true
//                        ConnectivityManager.TYPE_ETHERNET -> true
//                        else -> false
//                    }
//                }
//            }
//        }
//        return result
//    }

//    object callBack : ConnectivityManager.NetworkCallback() {
//
//        override fun onAvailable(network: Network) {
//            fet
////            onNetworkChange(true)
//        }
//
//        override fun onLost(network: Network) {
////            onNetworkChange(false)
//        }
//
//        override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
//            val isConnected = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
////            onNetworkChange(isConnected)
//        }
//    }
}
data class NetworkState(
    /** Determines if the network is connected. */
    val isConnected: Boolean,

    /** Determines if the network is validated - has a working Internet connection. */
    val isValidated: Boolean,

    /** Determines if the network is metered. */
    val isMetered: Boolean,

    /** Determines if the network is not roaming. */
    val isNotRoaming: Boolean
)

sealed class ConnectionState {
    object Available : ConnectionState()
    object Unavailable : ConnectionState()
}
