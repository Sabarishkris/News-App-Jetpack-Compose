package com.example.newsappjetpack.api




import com.example.newsappjetpack.datalayer.module.News
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query


private val BASE_URL = "https://inshortsapi.vercel.app"

val api: ApiResponse by lazy {
    Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(ApiResponse::class.java)
}

interface ApiResponse {

    @GET("/news?")
    suspend fun getTopHeadlines( @Query("category") category: String): Response<News>


}