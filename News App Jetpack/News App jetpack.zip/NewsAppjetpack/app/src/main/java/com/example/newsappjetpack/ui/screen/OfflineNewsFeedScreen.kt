package com.example.newsappjetpack.ui.screen

import android.os.Build
import android.util.Log
import androidx.annotation.RequiresExtension
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.CodeOff
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.example.newsappjetpack.datalayer.NewsData
import com.example.newsappjetpack.util.FeedViewModel
import com.example.newsappjetpack.util.Route

@OptIn(ExperimentalMaterial3Api::class)
@RequiresExtension(extension = Build.VERSION_CODES.S, version = 7)
@Composable
fun OfflineNewsFeedScreen(navigate: NavHostController, viewModel: FeedViewModel = hiltViewModel()) {
    val dbNews by viewModel.dbNews.collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Offline News",
                        fontSize = MaterialTheme.typography.titleLarge.fontSize
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                ),
                navigationIcon = {
                    IconButton(onClick = { navigate.popBackStack() }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(color = MaterialTheme.colorScheme.surface),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            OfflineFeed(viewModel = viewModel, navigate, dbNews)
        }

    }
}

@OptIn(ExperimentalFoundationApi::class)
@RequiresExtension(extension = Build.VERSION_CODES.S, version = 7)
@Composable
fun OfflineFeed(viewModel: FeedViewModel, navigate: NavHostController, dbNews: List<NewsData>) {
    val combinedNews = remember { mutableStateListOf<NewsData>() }
    LaunchedEffect(dbNews) {
        combinedNews.clear()
        combinedNews.addAll(dbNews)
    }
//    when (viewModel.uiState) {
//        is FeedViewModel.UiState.Loading -> {
//            Column(
//                modifier = Modifier.fillMaxSize(),
//                horizontalAlignment = Alignment.CenterHorizontally,
//                verticalArrangement = Arrangement.Center
//            ) {
//                CircularProgressIndicator(
//                    color = MaterialTheme.colorScheme.primary
//                )
//            }
//        }
//
//        is FeedViewModel.UiState.Success -> {
            LazyColumn {
                // Display items
                items(items = combinedNews,
                    key = { it.newsId }) { news ->
                    Log.d("msg",news.toString())
                    SwipeTODismissItem(
                        item = news,
                        onRemove = {
                            viewModel.delete(news)
                            combinedNews.remove(news)
                            Log.d("recompose", news.toString() + " " + combinedNews.size)
                        },
                        modifier = Modifier.animateItemPlacement(tween(200)),

                        navigate = navigate,
                        viewModel = viewModel
                    )
                }
            }
//        }
//
//        else -> {}
//    }
}
