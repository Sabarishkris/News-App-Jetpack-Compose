package com.example.cartonboxmeasurementapp.data

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.example.newsappjetpack.datalayer.NewsData
import com.example.newsappjetpack.datalayer.converters.Converters

@Database(entities = [NewsData::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class NewsDatabase: RoomDatabase() {
   abstract val dao:NewsDao
}