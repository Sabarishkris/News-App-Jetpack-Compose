package com.example.newsappjetpack.repository

import android.location.Location
import android.util.Log
import com.example.newsappjetpack.api.api
import com.example.newsappjetpack.api.weatherApi
import com.example.newsappjetpack.datalayer.NewsData
import com.example.newsappjetpack.datalayer.module.News
import com.example.newsappjetpack.util.Resource
import com.example.newsappjetpack.weather.WeatherInfo
import kotlinx.coroutines.flow.Flow
import retrofit2.Response

interface NewsRepository {

    suspend fun insert(news: NewsData)

    suspend fun delete(news: NewsData)

    suspend fun getNewsById(id:Int):NewsData?

    fun getNews(): Flow<List<NewsData>>

    suspend fun deleteAllNews()


//News Api  call
    suspend fun getTopHeadlines(category: String): Response<News> {
//        Log.d("impl","enter")
        return api.getTopHeadlines(category)
    }
    //Weather Api call
    suspend fun getWeatherData(lat: Double, long: Double): Resource<WeatherInfo>
}