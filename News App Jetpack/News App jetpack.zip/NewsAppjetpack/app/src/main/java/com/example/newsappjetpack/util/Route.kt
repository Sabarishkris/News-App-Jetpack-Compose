package com.example.newsappjetpack.util

object Route {
    const val NEWS_SCREEN="news_screen"
    const val NEWS_VIEW="news_view_screen"
    const val WEATHER_SCREEN="weather_screen"
    const val ADD_NEWS="add-news"
    const val OFFLINE_NEWS="offline-news"


}