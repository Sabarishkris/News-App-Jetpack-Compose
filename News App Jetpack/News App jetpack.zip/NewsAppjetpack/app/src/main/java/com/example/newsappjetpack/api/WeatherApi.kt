package com.example.newsappjetpack.api


import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

private val BASE_URL_weather = "https://api.open-meteo.com/"

val weatherApi:WeatherApi by lazy {
    Retrofit.Builder()
        .baseUrl(BASE_URL_weather)
        .addConverterFactory(MoshiConverterFactory.create())
        .build()
        .create(WeatherApi::class.java)
}


interface WeatherApi {
@GET("v1/forecast?hourly=temperature_2m,weathercode,relativehumidity_2m,windspeed_10m,pressure_msl")
suspend fun getWeatherData(
    @Query("latitude") lat: Double,
    @Query("longitude") long: Double
): WeatherDto
}