package com.example.cartonboxmeasurementapp.di

import android.app.Application
import androidx.room.Room
import com.example.cartonboxmeasurementapp.data.NewsDatabase
import com.example.newsappjetpack.api.WeatherApi
import com.example.newsappjetpack.repository.NewsRepository
import com.example.newsappjetpack.repository.NewsRepositoryImpl
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.create
import javax.inject.Singleton


@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides
    @Singleton
    fun provideReportDatabase(app: Application): NewsDatabase {
        return Room.databaseBuilder(app, NewsDatabase::class.java, "new").build()
    }

    @Provides
    @Singleton
    fun provideReportRepository(db:NewsDatabase):NewsRepository{
        return NewsRepositoryImpl(db.dao)
    }

    @Provides
    @Singleton
    fun provideFusedLocationProviderClient(app: Application): FusedLocationProviderClient {
        return LocationServices.getFusedLocationProviderClient(app)
    }
}
