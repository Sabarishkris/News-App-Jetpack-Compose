package com.example.newsappjetpack.datalayer.module

import androidx.compose.ui.graphics.vector.ImageVector

data class TabItem(
    val title: String,
    val unSelectedIcon: ImageVector,
    val selectedItem: ImageVector
)
