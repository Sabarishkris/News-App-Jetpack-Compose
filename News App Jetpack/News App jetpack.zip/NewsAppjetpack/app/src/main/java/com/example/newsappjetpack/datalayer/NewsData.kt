package com.example.newsappjetpack.datalayer

import android.graphics.Bitmap
import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(indices = [Index(value = ["title"], unique = true)])
data class NewsData(
    @ColumnInfo(name = "newsId")
    @PrimaryKey(autoGenerate = true)
    var newsId: Int,
    val author: String,
    val content: String,
    val date: String,
    val id: String,
    val imageUrl: Bitmap,
    val readMoreUrl: String,
    val time: String,
    val title: String,
    val url: String
):Parcelable
