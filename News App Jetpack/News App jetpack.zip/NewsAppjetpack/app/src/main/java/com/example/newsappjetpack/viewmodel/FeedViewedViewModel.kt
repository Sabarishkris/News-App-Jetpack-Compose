package com.example.newsappjetpack.viewmodel

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.util.Log
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import coil.ImageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.example.newsappjetpack.datalayer.NewsData
import com.example.newsappjetpack.datalayer.module.Data
import com.example.newsappjetpack.repository.NewsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

@HiltViewModel
class FeedViewedViewModel @Inject constructor(private val repository: NewsRepository) :
    ViewModel() {

    fun insertNews(context: Context, data: Data) {
        viewModelScope.launch {
            val bitmap = getBitmap(context, data.imageUrl)
            val news = bitmap?.let {
                NewsData(
                    newsId = 0,
                    author = data.author,
                    content = data.content,
                    date = data.date,
                    id = "Offline",
                    imageUrl = it,
                    readMoreUrl = data.readMoreUrl,
                    time = data.time,
                    title = data.title,
                    url = data.url
                )
            }
            news?.let {
                withContext(Dispatchers.IO) {
                    repository.insert(it)

                }
            }
        }
    }

    private suspend fun getBitmap(context: Context, url: String): Bitmap? {

        val imageLoader = ImageLoader(context)
        val request = ImageRequest.Builder(context)
            .data(url)
            .build()

        val result = imageLoader.execute(request)
        return (result as? SuccessResult)?.drawable?.toBitmap()
    }

    fun shareData(context: Context, data: Data) {
        val intent = Intent().apply {
            this.action = Intent.ACTION_SEND
            this.type = "text/plain"
//            this.putExtra("",data.toString())
            this.putExtra(
                Intent.EXTRA_TEXT,
                "Title : ${data.title} \n\nContent : ${data.content} \n\nImage :  ${data.imageUrl} \n\nCreated Date : ${data.date}"
            )
        }
        context.startActivity(
            Intent.createChooser(
                intent,
                data.title.toString()
            )
        )

    }
}
