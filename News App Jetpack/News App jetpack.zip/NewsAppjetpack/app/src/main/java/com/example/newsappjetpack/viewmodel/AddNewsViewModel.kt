package com.example.newsappjetpack.viewmodel

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.ImageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.example.newsappjetpack.datalayer.NewsData
import com.example.newsappjetpack.repository.NewsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

@HiltViewModel
class AddNewsViewModel @Inject constructor(val repository: NewsRepository) : ViewModel() {


    var readmore by mutableStateOf("")
    var content by mutableStateOf("")
    var title by mutableStateOf("")
    var selectedImage by mutableStateOf<Uri?>(null)
    fun insert(context: Context,author: String, date: String, id: String, time: String, url: String) {
        viewModelScope.launch {
            val bitmap = getBitmap(context, selectedImage.toString())
            val news = bitmap?.let {
                NewsData(
                    newsId = 0,
                    author = author,
                    content = content,
                    date = date,
                    id = id,
                    imageUrl = it,
                    readMoreUrl = readmore,
                    time = time,
                    title = title,
                    url = url
                )
            }
            Log.d("image",selectedImage.toString())
            news?.let {
                withContext(Dispatchers.IO) {
                    repository.insert(it)
                    Log.d("msg", news.toString())

                }
            }
        }
    }
    private suspend fun getBitmap(context: Context, url: String): Bitmap? {

        val imageLoader = ImageLoader(context)
        val request = ImageRequest.Builder(context)
            .data(url)
            .build()

        val result = imageLoader.execute(request)
        return (result as? SuccessResult)?.drawable?.toBitmap()
    }
}