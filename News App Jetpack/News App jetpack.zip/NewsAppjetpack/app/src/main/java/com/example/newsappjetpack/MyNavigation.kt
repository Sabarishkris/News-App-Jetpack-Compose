package com.example.newsappjetpack

import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.annotation.RequiresExtension
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.newsappjetpack.datalayer.NewsData
import com.example.newsappjetpack.datalayer.module.Data
import com.example.newsappjetpack.ui.screen.AddNewsScreen
import com.example.newsappjetpack.ui.screen.NewsDataViewScreen
import com.example.newsappjetpack.ui.screen.NewsScreen
import com.example.newsappjetpack.ui.screen.NewsViewScreen
import com.example.newsappjetpack.ui.screen.OfflineNewsFeedScreen
import com.example.newsappjetpack.util.Route


@RequiresApi(Build.VERSION_CODES.O)
@RequiresExtension(extension = Build.VERSION_CODES.S, version = 7)
@Composable
fun MyNavigation() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = Route.NEWS_SCREEN) {
        composable(route = Route.NEWS_SCREEN,
            enterTransition = {
                scaleIntoContainer()
            },
            exitTransition = {
                scaleOutOfContainer(direction = ScaleTransitionDirection.INWARDS)
            },
            popEnterTransition = {
                scaleIntoContainer(direction = ScaleTransitionDirection.OUTWARDS)
            },
            popExitTransition = {
                scaleOutOfContainer()
            }
        ) {
            NewsScreen(navController)
        }
        composable(route = Route.NEWS_VIEW,
//            arguments = listOf(navArgument(name = "newsId") {
//                type = NavType.IntType
//                defaultValue = -1
//            }),

            enterTransition = {
                scaleIntoContainer()
            },
            exitTransition = {
                scaleOutOfContainer(direction = ScaleTransitionDirection.INWARDS)
            },
            popEnterTransition = {
                scaleIntoContainer(direction = ScaleTransitionDirection.OUTWARDS)
            },
            popExitTransition = {
                scaleOutOfContainer()
            }
        ) {
            val news = navController.previousBackStackEntry?.savedStateHandle?.get<Any>("data")
            Log.d("Offline","entry")
            if (news is Data) {
                NewsViewScreen(news, navController)
            }
            if (news is NewsData) {
                NewsDataViewScreen(news, navController)

            }

        }
        composable(route = Route.OFFLINE_NEWS,
            enterTransition = {
                scaleIntoContainer()
            },
            exitTransition = {
                scaleOutOfContainer(direction = ScaleTransitionDirection.INWARDS)
            },
            popEnterTransition = {
                scaleIntoContainer(direction = ScaleTransitionDirection.OUTWARDS)
            },
            popExitTransition = {
                scaleOutOfContainer()
            }
        ) {
            OfflineNewsFeedScreen(navController)
        }

        composable(route = Route.ADD_NEWS,
            enterTransition = {
                scaleIntoContainer()
            },
            exitTransition = {
                scaleOutOfContainer(direction = ScaleTransitionDirection.INWARDS)
            },
            popEnterTransition = {
                scaleIntoContainer(direction = ScaleTransitionDirection.OUTWARDS)
            },
            popExitTransition = {
                scaleOutOfContainer()
            }
        ) {
            AddNewsScreen(navController)
        }
    }
}




fun scaleIntoContainer(
    direction: ScaleTransitionDirection = ScaleTransitionDirection.INWARDS,
    initialScale: Float = if (direction == ScaleTransitionDirection.OUTWARDS) 0.9f else 1.1f
): EnterTransition {
    return scaleIn(
        animationSpec = tween(220, delayMillis = 90),
        initialScale = initialScale
    ) + fadeIn(animationSpec = tween(220, delayMillis = 90))
}

fun scaleOutOfContainer(
    direction: ScaleTransitionDirection = ScaleTransitionDirection.OUTWARDS,
    targetScale: Float = if (direction == ScaleTransitionDirection.INWARDS) 0.9f else 1.1f
): ExitTransition {
    return scaleOut(
        animationSpec = tween(
            durationMillis = 220,
            delayMillis = 90
        ), targetScale = targetScale
    ) + fadeOut(tween(delayMillis = 90))
}

enum class ScaleTransitionDirection {
    INWARDS,
    OUTWARDS
}


//enterTransition = {
//    when (initialState.destination.route) {
//        "details" ->
//            slideIntoContainer(
//                AnimatedContentTransitionScope.SlideDirection.Left,
//                animationSpec = tween(700)
//            )
//
//        else -> null
//    }
//},
//exitTransition = {
//    when (targetState.destination.route) {
//        "details" ->
//            slideOutOfContainer(
//                AnimatedContentTransitionScope.SlideDirection.Left,
//                animationSpec = tween(700)
//            )
//
//        else -> null
//    }
//},
//popEnterTransition = {
//    when (initialState.destination.route) {
//        "details" ->
//            slideIntoContainer(
//                AnimatedContentTransitionScope.SlideDirection.Right,
//                animationSpec = tween(700)
//            )
//
//        else -> null
//    }
//},
//popExitTransition = {
//    when (targetState.destination.route) {
//        "details" ->
//            slideOutOfContainer(
//                AnimatedContentTransitionScope.SlideDirection.Right,
//                animationSpec = tween(700)
//            )
//
//        else -> null
//    }
//}
//) {